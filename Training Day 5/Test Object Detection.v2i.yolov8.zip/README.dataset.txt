# Test Object Detection > 2024-11-01 4:23am
https://universe.roboflow.com/-pjj2n/test-object-detection-mufmz

Provided by a Roboflow user
License: CC BY 4.0

